package AbstractFactory;

public class AbstractFactoryProducer {
    public static AbstractFactory getAbstractFactory(boolean isTrainee){
        if(isTrainee){
        return new TraineeProfessionAbstractFactory();
        }
        else {
            return  new ProfessionAbstractFactory();
        }
    }
}
