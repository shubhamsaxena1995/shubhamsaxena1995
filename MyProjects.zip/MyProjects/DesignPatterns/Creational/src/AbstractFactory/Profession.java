package AbstractFactory;

public interface Profession {
    void print();
}
