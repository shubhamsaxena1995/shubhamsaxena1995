package AbstractFactory;

public class AbstractFactoryPatternMainClass {
    public static void main(String[] args) {
        boolean isTrainee=true;
        AbstractFactory abstractFactory=AbstractFactoryProducer.getAbstractFactory(false);
        Profession profession=abstractFactory.getProfession("Doctor");
        profession.print();
    }
}
