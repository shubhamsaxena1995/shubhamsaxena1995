package AbstractFactory;

public class TraineeDoctor implements Profession{
    @Override
    public void print() {
        System.out.println("I am a Trainee Doctor");
    }
}
