package Factory;

public interface Profession {
    void print();
}
