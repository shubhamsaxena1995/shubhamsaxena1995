package Singleton;

public class SingletonWithEagerLoading {
    private static SingletonWithEagerLoading singletonWithEagerLoading =new SingletonWithEagerLoading();
    private SingletonWithEagerLoading(){
    }
    public SingletonWithEagerLoading getSingletonInstanse(){
    return singletonWithEagerLoading;
    }
    public void printInstance(){
        System.out.println("Hashcode of singleton object"+singletonWithEagerLoading);
    }
}
