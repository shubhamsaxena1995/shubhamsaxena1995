package Singleton;

public class SingletonWithThreadSafety {
}
