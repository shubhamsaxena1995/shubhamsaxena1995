package Singleton;

public class SingletonWithLazyLoading {
    private static SingletonWithLazyLoading singletonWithLazyLoading ;
    private SingletonWithLazyLoading(){
    }
    public SingletonWithLazyLoading getSingletonInstanse(){
        if(singletonWithLazyLoading==null){
            singletonWithLazyLoading= new SingletonWithLazyLoading();
        }
        return singletonWithLazyLoading;
    }
    public void printInstance(){
        System.out.println("Hashcode of singleton object"+singletonWithLazyLoading);
    }
}
