package com.demo.spring;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, Long> {
	
	public List<Employee> findByName(String name);
	public Long countByName(String name);
	List<Employee> findByNameOrderByEmailDesc(String name);
	List<Employee> findByNameAndAddress(String name, String address);
	
	Page<Employee> findAll(Pageable pageable);
	
	
	public Employee findById(Integer id);
	public void deleteById(Integer id);
	
	//Pagination
	
	//hibernate query(JPQL)
	@Query(value = "SELECT e FROM Employee e ORDER BY email")
	Page<Employee> findAllEmployeesWithPagination(Pageable pageable);
	
	//SQL query
	@Query(
			  value = "SELECT * FROM employee e ORDER BY name", 
			  nativeQuery = true)
	Page<Employee> findAllEmployeesWithPaginationNative(Pageable pageable);
	
	//Sorting
	
	//Sort in JPQL
	@Query(value = "SELECT e FROM Employee e")
	List<Employee> findAllEmployees(Sort sort);
	
	//No sorting in SQL
	
	//Indexed query param
	@Query("SELECT e FROM Employee e WHERE e.name = ?1")
	List<Employee> findEmployeeByName(String name);
	
	//SQl query similar to JPQL(replace table name in place of Entitiy name)
	
	//Named parameter
	@Query("SELECT e FROM Employee e WHERE e.id = :id")
	Employee findEmployeeByIdNamedParams(@Param("id") Integer id);
	
	//Modifying
	@Modifying
	@Query("update Employee e set e.email = :email where e.id = :id")
	int updateEmployeeSetEmailForId(@Param("id") Integer id, 
	  @Param("email") String email);
	
	public List<Employee> findByNameNamed(String name);
}