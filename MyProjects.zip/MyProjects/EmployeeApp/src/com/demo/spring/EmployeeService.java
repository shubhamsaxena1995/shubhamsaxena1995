package com.demo.spring;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EmployeeService {
	@Autowired 
	EmployeeRepository repo;
    
    public void save(Employee Employee) {
        repo.save(Employee);
    }
     
    public List<Employee> listAll() {
        return (List<Employee>) repo.findAll();
    }
     
    public Employee get(Integer id) {
        return repo.findById(id);
    }
     
    public void delete(Integer id) {
        repo.deleteById(id);
    }
    
    public void update(Long id) {
        if(repo.existsById(id)){
        	Optional<Employee> emp=repo.findById(id);
        	repo.save(emp.get());
        }
    }
    
    public List<Employee> getByName(String name) {
        return repo.findByName(name);
    }
    
    public Long countByName(String name) {
        return repo.countByName(name);
    }
    
    public List<Employee> findByNameOrderByEmailDesc(String name) {
        return repo.findByNameOrderByEmailDesc(name);
    }
    
    public List<Employee> findByNameAndAddress(String name, String address) {
        return repo.findByNameAndAddress(name, address);
    }
    
  
    
    @SuppressWarnings("deprecation")
	public Page<Employee> findAllSorting(){
    	Pageable pageable = new PageRequest(0, 3);
    	Sort.Order order1 = new Sort.Order(Sort.Direction.ASC, "id");
    	Sort.Order order2 = new Sort.Order(Sort.Direction.DESC, "name");
    	Sort sort = new Sort(order1, order2);
    	pageable = new PageRequest(0, 3, sort);
    	//pageable = new PageRequest(0, 10, new Sort(Sort.Direction.DESC, "name"));
    	return repo.findAll(pageable);
    	
    }
    
    @SuppressWarnings("deprecation")
	public Page<Employee> findAllEmployeesWithPagination(){
    	Pageable pageable = new PageRequest(0, 5);
    	return repo.findAllEmployeesWithPagination(pageable);
    	
    }
    
    @SuppressWarnings("deprecation")
	public Page<Employee> findAllEmployeesWithPaginationNative(){
    	Pageable pageable = new PageRequest(0, 3);
    	return repo.findAllEmployeesWithPaginationNative(pageable);
    	
    }
    

   	public List<Employee> findAllEmployees(){
       	return repo.findAllEmployees(Sort.by("name").descending());
       	
    }
   	
   	public List<Employee> findEmployeeByName(String name){
       	return repo.findEmployeeByName(name);   	
    }
   	
   	public Employee findEmployeeByIdNamedParams(Integer id){
       	return repo.findEmployeeByIdNamedParams(id);   	
    }
   	
   	public int updateEmployeeSetEmailForId(Integer id, 
   		 String email){
   		return repo.updateEmployeeSetEmailForId(id,email);   	
   	}
   	
   	public List<Employee> findByNameNamed(String name){
       	return repo.findByNameNamed(name);   	
    }
   	
}
