package com.demo.spring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
 
 
@RestController
public class EmployeeController {
 
    @Autowired
    private EmployeeService empService;
 
    @RequestMapping(value="/getListOfEmployees", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Employee> getListOfEmployees() {
        List<Employee> employeeList = empService.listAll();
        return employeeList;
    }
    
  @RequestMapping(value="/getEmployeeById/{id}", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public Employee getEmployeeById(@PathVariable Integer id) {
      Employee emp = empService.get(id);
      return emp;
  }
    
    @RequestMapping(value="/createEmployee", method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @ResponseStatus(code=HttpStatus.CREATED)
    public void createEmployee(@RequestBody Employee emp) {
       empService.save(emp);
    }
    
  @RequestMapping(value="/deleteEmployee/{id}", method=RequestMethod.DELETE,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  @ResponseStatus(code=HttpStatus.NO_CONTENT)
  @Transactional
  public void deleteEmployee(@PathVariable Integer id) {
     empService.delete(id);
  }
    
    @RequestMapping(value="/updateEmployee{id}", method=RequestMethod.DELETE,produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @ResponseStatus(code=HttpStatus.NO_CONTENT)
    public void updateEmployee(@PathVariable Long id) {
       empService.update(id);
    }
    
  @RequestMapping(value="/getEmployeeByName/{name}", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public List<Employee> getEmployeeByName(@PathVariable String name) {
      List<Employee> emp = empService.getByName(name);
      return emp;
  }
  
  @RequestMapping(value="/countEmployeeByName/{name}", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public Long countEmployeeByName(@PathVariable String name) {
      Long emp = empService.countByName(name);
      return emp;
  }
  
  @RequestMapping(value="/findByNameOrderByEmailDesc/{name}", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public List<Employee> findByNameOrderByEmailDesc(@PathVariable String name) {
      List<Employee> emp = empService.findByNameOrderByEmailDesc(name);
      return emp;
  }
  
  @RequestMapping(value="/findByNameAndAddress/{name}/{address}", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public List<Employee> findByNameAndAddress(@PathVariable String name,@PathVariable String address) {
      List<Employee> emp = empService.findByNameAndAddress(name, address);
      return emp;
  }
  
  
  
  @RequestMapping(value="/findAllSorting", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public Page<Employee> findAllSorting() {
      Page<Employee> emp = empService.findAllSorting();
      return emp;
  }
  
  @RequestMapping(value="/findAllEmployeesWithPagination", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public Page<Employee> findAllEmployeesWithPagination() {
      Page<Employee> emp = empService.findAllEmployeesWithPagination();
      return emp;
  }
  
  @RequestMapping(value="/findAllEmployeesWithPaginationNative", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public Page<Employee> findAllEmployeesWithPaginationNative() {
      Page<Employee> emp = empService.findAllEmployeesWithPaginationNative();
      return emp;
  }
  
  @RequestMapping(value="/findAllEmployees", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public List<Employee> findAllEmployees() {
      List<Employee> emp = empService.findAllEmployees();
      return emp;
  }
  
  @RequestMapping(value="/findEmployeeByName/{name}", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public List<Employee> findEmployeeByName(@PathVariable String name) {
      List<Employee> emp = empService.findEmployeeByName(name);
      return emp;
  }
  
  @RequestMapping(value="/findEmployeeByIdNamedParams/{id}", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public Employee findEmployeeByIdNamedParams(@PathVariable Integer id) {
      Employee emp = empService.findEmployeeByIdNamedParams(id);
      return emp;
  }
  
  @RequestMapping(value="/updateEmployeeSetEmailForId/{id}/{email}", method=RequestMethod.PUT,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  @ResponseStatus(code=HttpStatus.NO_CONTENT)
  @Transactional
  public int updateEmployeeSetEmailForId(@PathVariable Integer id,@PathVariable String email) {
      int emp = empService.updateEmployeeSetEmailForId(id,email);
      return emp;
  }
  
  @RequestMapping(value="/findByNameNamed/{name}", method=RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public List<Employee> findByNameNamed(@PathVariable String name) {
      List<Employee> emp = empService.findByNameNamed(name);
      return emp;
  }
}

