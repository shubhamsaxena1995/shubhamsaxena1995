package immutable;

public class Address implements Cloneable {
  private String currentAddress;
  private String permanent;
    public Object clone() throws CloneNotSupportedException
    {
        return super.clone();
    }
    public Address(String currentAddress, String permanent) {
        this.currentAddress = currentAddress;
        this.permanent = permanent;
    }

    private String getCurrentAddress() {
        return currentAddress;
    }

    private String getPermanent() {
        return permanent;
    }

    @Override
    public String toString() {
        return "Address{" +
                "currentAddress='" + currentAddress + '\'' +
                ", permanent='" + permanent + '\'' +
                '}';
    }
}
