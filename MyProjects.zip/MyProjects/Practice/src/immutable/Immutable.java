package immutable;

import java.util.ArrayList;
import java.util.List;

public final class Immutable {
    private final String name;
    private final List<String> address;

    public Immutable(String name,List<String>address){
        this.name=name;
        List<String> tempAddress=new ArrayList<>();
        for(String add:address){
            tempAddress.add(add);
        }
        this.address=tempAddress;
    }

    public String getName() {
        return name;
    }

    public List<String> getAddress() {
        List<String> tempAddress=new ArrayList<>();
        for(String add:address){
            tempAddress.add(add);
        }
        return tempAddress;
    }
    public static void main(String args[]){
        List <String>list=new ArrayList<>();
        list.add("abc");
        list.add("def");

        Immutable testDemp=new Immutable("shubham",list);

        System.out.println(testDemp.getAddress());
        testDemp.getAddress().add("asdsa");
        System.out.println(testDemp.getAddress());
    }
}

