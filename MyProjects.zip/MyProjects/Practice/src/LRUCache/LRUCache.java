package LRUCache;

import java.util.*;

public class LRUCache {
    private Set<Integer> cache;
    private int capacity;

    LRUCache(int capacity){
     this.cache=new LinkedHashSet<>(capacity);
     this.capacity=capacity;
    }
    /* Refers key x with in the LRU cache */
    // This function add key in cache if key is not
    // present in cache. Else it moves the key to
    // front by first removing it and then adding it
    public void refer(int key){
        //if key is not present
        if(!cache.contains(key)){
            put(key);
        }
        else{  //if key is present we will shift to most recently used position
            cache.remove(key);
            cache.add(key);
        }
    }
    // This function add key at most recently used position
    // If the capacity is full then is will remove least recently used key
    // and add the key to the most recently used position
    public void put(int key){
        //if the cache is full then remove Least recently used key
        if(cache.size()==capacity){
            int firstKey=cache.iterator().next();
            cache.remove(firstKey);
        }
            cache.add(key);
    }
    // displays contents of cache in Reverse Order
    public void display(){
        LinkedList<Integer> linkedList=new LinkedList(cache);
        // The descendingIterator() method of java.util.LinkedList
        // class is used to return an iterator over the elements
        // in this LinkedList in reverse sequential order
        Iterator<Integer> iterator=linkedList.descendingIterator();
        while(iterator.hasNext()){
            System.out.print(iterator.next()+ "  ");
        }
    }

    public static void main(String[] args) {
        LRUCache lruCache=new LRUCache(4);
        lruCache.refer(1);
        lruCache.refer(2);
        lruCache.refer(3);
        lruCache.refer(1);
        lruCache.refer(4);
        lruCache.refer(5);
        lruCache.display();
    }
}
