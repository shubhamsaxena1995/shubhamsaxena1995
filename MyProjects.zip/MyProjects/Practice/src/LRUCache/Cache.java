package LRUCache;


import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Set;

public class Cache {
    private Set<Integer> cache;
    private int capacity;
    Cache(int capacity){
        this.capacity=capacity;
        this.cache =new LinkedHashSet<>(capacity);
    }
    public void refer(int key){
        if(cache.contains(key)){
            cache.remove(key);
            cache.add(key);
        }
        else {
            put(key);
        }
    }

    private void put(int key) {
     if(cache.size()==capacity){
        int leastRecent =cache.iterator().next();
        cache.remove(leastRecent);
     }
       cache.add(key);
    }

    private void display(){
        LinkedList<Integer> linkedList=new LinkedList(cache);
        Iterator itr=linkedList.descendingIterator();
        while (itr.hasNext()){
            System.out.print(itr.next()+" ");
        }
    }

    public static void main(String[] args) {
        Cache lruCache=new Cache(4);
        lruCache.refer(1);
        lruCache.refer(2);
        lruCache.refer(3);
        lruCache.refer(1);
        lruCache.refer(4);
        lruCache.refer(5);
        lruCache.display();
    }
}
