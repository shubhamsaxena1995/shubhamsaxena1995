package RestPrototype;
public class StudentRestExceptionHandler {
/*
@ControllerAdvice
public class StudentRestExceptionHandler {

@ExceptionHandler
    public ResponseEntity<StudentErrorResponse> handleException(StudentNotFoundException ex){
     StudentErrorResponse studentErrorResponse= new StudentErrorResponse();
     studentErrorResponse.setStatus(HttpStatus.NOT_FOUND.value());
     studentErrorResponse.setMessage(ex.getMessage());
     studentErrorResponse.setTimeStamp(System.currentTimeMillis());
    return   new ResponseEntity(studentErrorResponse,HttpStatus.NOT_FOUND);
}

    @ExceptionHandler
    public ResponseEntity<StudentErrorResponse> handleException(Exception ex){
        StudentErrorResponse studentErrorResponse= new StudentErrorResponse();
        studentErrorResponse.setStatus(HttpStatus.BAD_REQUEST.value());
        studentErrorResponse.setMessage(ex.getMessage());
        studentErrorResponse.setTimeStamp(System.currentTimeMillis());
        return new ResponseEntity(studentErrorResponse,HttpStatus.BAD_REQUEST);
    }*/
}
