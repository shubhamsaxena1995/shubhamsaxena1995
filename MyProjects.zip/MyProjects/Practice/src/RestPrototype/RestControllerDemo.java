package RestPrototype;

import java.util.ArrayList;

public class RestControllerDemo {
/*
@RestController
@RequestMapping("/api")
public class RestControllerDemo {

     @GetMapping("/students")
    public List<Strudent>  getStudents(){
          List <Student> list = new ArrayList();
          list.add(new Student (1,"studentName"));
          list.add(new Student (2,"studentName2"));
          list.add(new Student (3,"studentName3"));
         return list;
    }


    @GetMapping("/students/{studentId}")                //should be same as{studentId}
    public List<Strudent>  getStudent(@pathVariable int studentId){
           if(studentId >=list.size()||studentId<0){
            throw new StudentNotFoundException("studentId not found - "+studentId);
           }
        return list.get(studentId);
    }
     @ExceptionHandler
    public ResponseEntity<StudentErrorResponse> handleException(StudentNotFoundException ex){
          StudentErrorResponse error=new StudentErrorResponse();
          error.setStatus(HttpStatus.NOT_FOUND.value());
          error.setMessage(ex.getMessage());
          error.setTimeStamp(System.currentTimeMillis());
          return new ResponseEntity<StudentErrorResponse>(error,HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler
    public ResponseEntity<StudentErrorResponse> handleException(Exception ex){
        StudentErrorResponse error=new StudentErrorResponse();
        error.setStatus(HttpStatus.BAD_REQUEST.value());
        error.setMessage(ex.getMessage());
        error.setTimeStamp(System.currentTimeMillis());
        return new ResponseEntity<StudentErrorResponse>(error,HttpStatus.BAD_REQUEST);
    }
*/

}
