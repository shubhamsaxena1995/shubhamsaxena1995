package RestPrototype;

public class StudentErrorResponse {
    private int status;
    private String message;
    private long timeStamp;

    //contructors

    //getters / setters

}
