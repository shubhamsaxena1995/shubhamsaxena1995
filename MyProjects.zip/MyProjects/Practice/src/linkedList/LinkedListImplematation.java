package linkedList;

import java.util.Currency;

public class LinkedListImplematation {

    Node head;

    static class Node {
        int data;
        Node next;
        Node(int data){
            this.data=data;
            this.next=null;
        }
    }
    // 1 2 3 4 5
    public static LinkedListImplematation insert(LinkedListImplematation list,
                                                 int data){
        Node new_node=new Node(data);
        new_node.next = null;
        if(list.head==null){
            list.head=new_node;
        }
        else {
            Node last=list.head;
            while (last.next!=null){
                last=last.next;
            }
            last.next=new_node;
        }
        return list;
    }

    public static void printList(LinkedListImplematation list){
        Node currentNode=list.head;
        System.out.println("LinkedList:");
        while (currentNode!=null){
            System.out.println(currentNode.data+" ");

            currentNode=currentNode.next;
        }
    }
    public static LinkedListImplematation deleteByKey(LinkedListImplematation list,int key){
             Node currentNode=list.head, prev=null;

             if(currentNode!=null && currentNode.data==key){
                 list.head=currentNode.next;

                 System.out.println(key + " found and deleted");

                 return list;
             }

             while(currentNode!=null&&currentNode.data!=key){

                 prev=currentNode;
                 currentNode=currentNode.next;

             }
             if(currentNode!=null){
                 prev.next = currentNode.next;
                 System.out.println(key + " found and deleted");
             }
             if(currentNode==null){
                 System.out.println(key + " not found");
             }
             return list;
    }

    public static LinkedListImplematation deleteAtPosition(LinkedListImplematation list, int index){
        Node currentNode=list.head,prev=null;
        if(index ==0&&currentNode!=null){
           list.head=currentNode.next;
            System.out.println(
                    index + " position element deleted");
            return list;
        }
           int counter=0;
        while (currentNode!=null){
            if(counter==index){
                prev.next=currentNode.next;
                System.out.println(
                        index + " position element deleted");
                break;
            }
            else {
                prev=currentNode;
                currentNode=currentNode.next;
                counter++;
            }
        }
        if (currentNode == null) {
            // Display the message
            System.out.println(
                    index + " position element not found");
        }
        return list;
    }
    public static void main(String[] args)
    {
        /* Start with the empty list. */
        LinkedListImplematation list = new LinkedListImplematation();

        //
        // ******INSERTION******
        //

        // Insert the values
        list = insert(list, 1);
        list = insert(list, 2);
        list = insert(list, 3);
        list = insert(list, 4);
        list = insert(list, 5);
        list = insert(list, 6);
        list = insert(list, 7);
        list = insert(list, 8);


        // Print the LinkedList
        printList(list);
        // Delete node with value 1
        // In this case the key is ***at head***
        deleteByKey(list, 1);

        // Print the LinkedList
        printList(list);

        // Delete node with value 4
        // In this case the key is present ***in the
        // middle***
        deleteByKey(list, 4);

        // Print the LinkedList
        printList(list);

        // Delete node with value 10
        // In this case the key is ***not present***
        deleteByKey(list, 10);

        // Print the LinkedList
        printList(list);

        deleteAtPosition(list, 2);

        // Print the LinkedList
        printList(list);

        // Delete node at position 10
        // In this case the key is ***not present***
        deleteAtPosition(list, 10);

        // Print the LinkedList
        printList(list);


        printMiddileNode(list);
    }
    public static void printMiddileNode(LinkedListImplematation list){
        Node currentNode=list.head;
        Node middleNode=currentNode;
         int count=0;
        while(currentNode!=null){
          if(count%2==1){
             middleNode=middleNode.next;
          }
          count++;
          currentNode=currentNode.next;
        }
        if (middleNode != null)
            System.out.println("The middle element is [" +
                    middleNode.data + "]\n");
            }
}
