package arrayProblem;

import java.util.ArrayList;

public class MergeThreeSortedArray {
    public static void main(String[] args) {
        int A[] = { 1, 2, 41, 52, 84 };
        int B[] = { 1, 2, 41, 52, 67 };
        int C[] = { 1, 2, 41, 52, 67, 85 };
        mergeSortedArray(A,B,C);
    }
    private static void mergeSortedArray(int [] arr1,int [] arr2,int [] arr3) {
      int m=arr1.length;
      int n=arr2.length;
      int o=arr3.length;
      int i=0,j=0,k=0;
      ArrayList <Integer>arrayList=new ArrayList();
        // using merge concept and trying to find
        // smallest of three while all three arrays
        // contains at least one element
      while(i<m&&j<n&&k<o){
       int a=arr1[i];
       int b=arr2[j];
       int c=arr3[k];
       if(a<=b&&a<=c){
           arrayList.add(a);
           i++;
       }
       else if (b<=c&&b<=a){
           arrayList.add(b);
           j++;
       }
       else {
           arrayList.add(c);
           k++;
       }
      }

        // next three while loop is to sort two
        // of arrays if one of the three gets exhausted
        while(i<m&&j<n){
            if(arr1[i]<arr2[j]){
              arrayList.add(arr1[i]);
              i++;
            }
            else {
                arrayList.add(arr2[j]);
                j++;
            }
        }
        while (j<n&&k<o){
            if(arr2[j]<arr3[k]){
                arrayList.add(arr2[j]);
                j++;
            }
            else {
                arrayList.add(arr3[k]);
                k++;
            }
        }
        while (k<o&&i<m){
            if(arr3[k]<arr1[i]){
                arrayList.add(arr3[k]);
                k++;
            }
            else {
                arrayList.add(arr1[i]);
                i++;
            }
        }
        // if one of the array are left then
        // simply appending them as there will
        // be only largest element left
        while (i<m){
            arrayList.add(arr1[i]);
            i++;
        }while (j<n){
            arrayList.add(arr2[j]);
            j++;
        }while (k<o){
            arrayList.add(arr3[k]);
            k++;
        }
        for (Integer x : arrayList){
            System.out.print(x + " ");
      }

    }
}
