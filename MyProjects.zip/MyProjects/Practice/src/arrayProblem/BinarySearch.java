package arrayProblem;

public class BinarySearch {
    public static void main(String[] args) {
        int arr[] = { 2, 3, 4, 10, 40 };
        System.out.println(binarySearch(arr,0,arr.length-1,10));
        System.out.println(binarySearch(arr,0,arr.length-1,3));
        System.out.println(binarySearch(arr,0,arr.length-1,15));
    }
    private static int binarySearch(int []arr,int beg,int end,int element) {
         int mid=(beg+end)/2;
         if(end<beg){
             return -1;
         }
         if(arr[mid]==element){
             return mid;
         }
         if(arr[mid]>element){
             return binarySearch(arr,beg,mid-1,element);
         }
         return binarySearch(arr,mid+1,end,element);
    }
}
