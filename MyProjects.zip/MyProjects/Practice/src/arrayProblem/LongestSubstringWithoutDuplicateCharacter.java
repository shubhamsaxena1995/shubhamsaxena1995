package arrayProblem;

import java.util.HashMap;

public class LongestSubstringWithoutDuplicateCharacter {
    public static void main(String[] args) {
        //   String s="airtelxlab";
       String s="geeksforgeeks";
        System.out.println("The input is "+s);
        int length =longestUniqueSubsttr(s);
        System.out.println("The length of longest substring without duplicate characters is "+length);
    }

    private static int longestUniqueSubsttr(String s) {
        int start=0;
        int maxLength=0;
        HashMap<Character,Integer>map=new HashMap();
        for(int end=0;end<s.length();end++){
            if(map.containsKey(s.charAt(end))){
                //a b c a --b a c d b a
                start=Math.max(start,map.get(s.charAt(end))+1);
            }
            map.put(s.charAt(end),end);
            maxLength=Math.max(maxLength,end-start+1);
        }
        return maxLength;
    }
}
