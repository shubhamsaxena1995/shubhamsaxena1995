package arrayProblem;

import jdk.internal.org.objectweb.asm.tree.InnerClassNode;

import java.util.Arrays;
import java.util.HashSet;

public class PrintArrayPairsWithSumK {

    public static void main(String[] args) {
        printPairsUsingSet( new int[]{  15, 0, 14, 0, 4, 7, 8, 3, 5, 7,-4 }, 11);
        printPairsUsingTwoPointers(new int[]{  15, 0, 14, 0, 4, 7, 8, 3, 5, 7,-4 }, 11);
    }

    private static void printPairsUsingSet(int[] inputArray, int k) {

        if(inputArray!=null && inputArray.length<2){
            return;
        }
        HashSet<Integer> hashSet=new HashSet<>(inputArray.length);
        for (int value:inputArray){
            int target = k-value;
            if(!hashSet.contains(target)){
                hashSet.add(value);
            }
            else {
                System.out.println("["+value+ " , "+ target+"]");
            }
        }
    }

    /**
     * The complexity of this solution would be O(NlogN) due to sorting.
     * Remember to use a in-place sorting algorithm like quicksort to sort the array as we don't have additional space.
     * Thankfully, Arrays.sort() method uses a two pivot quicksort algorithm to sort array of primitives.
     */
    private static void printPairsUsingTwoPointers(int[] inputArray, int k) {
        System.out.println("_________________________________________________________________________________");
        if(inputArray!=null && inputArray.length<2){
            return;
        }
        Arrays.sort(inputArray);
        //15, 0, 14, 0, 4, 7, 8, 3, 5, 7,-4
        // -4,0,3,4,5,7,7,8,14,15
      int left=0, right=inputArray.length-1;
        while(left<right){
           int sum =inputArray[left]+inputArray[right];
            if(sum==k){
                System.out.println("["+inputArray[left]+ " , "+ inputArray[right]+"]");
              left++;
              right--;
            }
            else if(sum<k){
                left++;
            }
            else if(sum>k){
                right--;
            }
        }
    }
}
