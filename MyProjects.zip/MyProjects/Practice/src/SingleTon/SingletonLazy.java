package SingleTon;

public class SingletonLazy {
    private static SingletonLazy singletonLazyObj;

    private SingletonLazy() {
    }
public static SingletonLazy getInstance(){
    if(singletonLazyObj ==null){
        singletonLazyObj =new SingletonLazy();
    }
        return singletonLazyObj;
}
}

