package SingleTon;

public class SingleTonDoubleCheck {
    private static SingleTonDoubleCheck singleTonDoubleCheck;

    private SingleTonDoubleCheck() {
    }
     public static SingleTonDoubleCheck getInstance(){
        if(singleTonDoubleCheck ==null){

            synchronized (SingleTonDoubleCheck.class){

                singleTonDoubleCheck =new SingleTonDoubleCheck();
        }

        }
        return singleTonDoubleCheck;
    }
}

