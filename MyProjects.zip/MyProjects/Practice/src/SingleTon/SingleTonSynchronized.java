package SingleTon;

public class SingleTonSynchronized {
    private static SingleTonSynchronized singleTonSynchronized;

    private SingleTonSynchronized() {
    }
   synchronized public static SingleTonSynchronized getInstance(){
        if(singleTonSynchronized ==null){
            singleTonSynchronized =new SingleTonSynchronized();
        }
        return singleTonSynchronized;
    }
}

