package SingleTon;

public class Demo {

    public static void main(String[] args) throws InterruptedException {
            MyThread myThread=new MyThread();
            myThread.start();

            SingletonLazy singletonLazy1 = SingletonLazy.getInstance();
            SingletonLazy singletonLazy2 = SingletonLazy.getInstance();
            System.out.println(singletonLazy1);
            System.out.println(singletonLazy2);

            SingleTonSynchronized singleTonSynchronized1=SingleTonSynchronized.getInstance();
            SingleTonSynchronized singleTonSynchronized2=SingleTonSynchronized.getInstance();
            System.out.println(singleTonSynchronized1);
            System.out.println(singleTonSynchronized2);

        SingleTonDoubleCheck singleTonDoubleCheck1=SingleTonDoubleCheck.getInstance();
        SingleTonDoubleCheck singleTonDoubleCheck2=SingleTonDoubleCheck.getInstance();
        System.out.println(singleTonDoubleCheck1);
        System.out.println(singleTonDoubleCheck2);
        }

}
