package SingleTon;

public class MyThread extends Thread {
public void run(){
    for(int i=0;i<10;i++) {
        SingletonLazy singletonLazy1 = SingletonLazy.getInstance();
        SingleTonSynchronized singleTonSynchronized1=SingleTonSynchronized.getInstance();
        SingleTonDoubleCheck singleTonDoubleCheck=SingleTonDoubleCheck.getInstance();
        System.out.println(singletonLazy1);
        System.out.println(singleTonSynchronized1);
        System.out.println(singleTonDoubleCheck);
    }
    }
}
