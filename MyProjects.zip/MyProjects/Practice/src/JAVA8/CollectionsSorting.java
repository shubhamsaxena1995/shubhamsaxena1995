package JAVA8;


import java.util.*;
import java.util.stream.Collectors;

public class CollectionsSorting {
    public static void main(String[] args) {
        sortingArrayList();
        sortingSet();
        sortingMap();
        sortingMapWithValue();
        sortingEmployeeWithId();

    }

    private static void sortingArrayList() {
        ArrayList<Integer> al=new ArrayList<>();
        al.add(5);
        al.add(2);
        al.add(7);
        al.add(3);
        al.add(11);
        System.out.println(al);
        List sortedAl;
        sortedAl= al.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        sortedAl= al.stream().sorted((a,b)->b.compareTo(a)).collect(Collectors.toList());
        sortedAl= al.stream().sorted((a,b)->a<b?1:b<a?-1:0).collect(Collectors.toList());
        System.out.println("SortedList"+sortedAl);

    }
    private static void sortingSet() {
        TreeSet<Integer> treeSet=new TreeSet<>((a, b)->a<b?1:a>b?-1:0);
        treeSet.add(5);
        treeSet.add(2);
        treeSet.add(7);
        treeSet.add(3);
        treeSet.add(11);
        System.out.println("SortedSet"+treeSet);
    }

    private static void sortingMap() {
        TreeMap<Integer,String> treeMap=new TreeMap<>((Comparator.reverseOrder()));
        treeMap.put(5,"cven");
        treeMap.put(2,"wissen");
        treeMap.put(7,"altimetric");
        treeMap.put(3,"amadeus");
        treeMap.put(11,"itc");
        System.out.println("Sorting map by key"+treeMap);
    }
    private static void sortingMapWithValue() {
        HashMap<Integer,String> hashMap=new HashMap<>();
        hashMap.put(5,"cven");
        hashMap.put(2,"wissen");
        hashMap.put(7,"wissen");
        hashMap.put(21,"altimetric");
        hashMap.put(13,"amadeus");
        hashMap.put(11,"itc");
        System.out.println("hashmap"+hashMap);


        Map<Integer,String> sortedMap = hashMap.entrySet().stream().sorted(Map.Entry.comparingByValue()).collect(Collectors.toMap(a->a.getKey(),a->a.getValue(),(a,b)->a,()->new LinkedHashMap<>()));
        System.out.println("Sorting hashmap by Value"+sortedMap);

        //https://www.geeksforgeeks.org/collectors-tomap-method-in-java-with-examples/
        //above example explains about mergerFunction (a,b)->a
        //(s, a) -> s + ", " + a  if we have two value associates with duplicate key then how we are going to map that key and value in this exaple we are keeping as "," separated value EX:
        //{ "GFG", "GeeksForGeeks" },
        // { "g", "geeks" },
        //{ "GFG", "geeksforgeeks" }
        //Map:{g=geeks, GFG=GeeksForGeeks, geeksforgeeks}
    }
    private static void sortingEmployeeWithId() {
       ArrayList<Employee> employees=new ArrayList<>();
       employees.add(new Employee(2,"shubham"));
       employees.add(new Employee(5,"ajay"));
       employees.add(new Employee(3,"Sonam"));
       employees.add(new Employee(1,"Ritika"));

       List sortedList=employees.stream().sorted((a,b)->a.getId()<b.getId()?1: a.getId()>b.getId()?-1:0).collect(Collectors.toList());
        System.out.println(sortedList);
    }
}
