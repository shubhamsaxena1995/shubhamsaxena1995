package JAVA8;
import java.sql.SQLOutput;
import java.util.*;
import java.util.stream.Collectors;

// you can also use imports, for example:
// import java.util.*;
public class Solution {
    private static int count=0;
    public static void main(String [] args) {
        // you can write to stdout for debugging purposes, e.g.
        System.out.println("This is a debug message");
        Integer[] arrayInput = new Integer[]{2, 4, 3, 5, 7, 8, 9};
        Integer[] arrayInput1 = new Integer[]{};
        System.out.println(numberOfSubarray(arrayInput));
        System.out.println(numberOfSubarray(arrayInput1));

        System.out.println("__________________________________________________");
    }

    private static int numberOfSubarray(Integer [] array){
        if(array!=null&&array.length<1){
            return 0;
        }

        List list=Arrays.asList(array);

        List <Integer>sortedList= (List<Integer>) list.stream().sorted().collect(Collectors.toList());
        for(int i=0;i<sortedList.size();i++){
            for(int j=i;j<sortedList.size();j++){

                if(isSumSeven(sortedList.get(i),sortedList.get(j))){
                    count++;
                }
            }
        }
        return count;
    }
    private static boolean isSumSeven(Integer a, Integer b){
        return a+b ==7;
    }
































}
