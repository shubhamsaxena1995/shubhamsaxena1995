package JAVA8;

import java.util.*;

public class StreamPrograms {
    public static void main(String[] args) {
         List<Integer> myList = Arrays.asList(10,15,8,49,25,98,32,8,49);
        //Q1:Given a list of integers, find out all the numbers starting with 1 using Stream functions?
        myList.stream().map(a->a+"").filter(a->a.startsWith("1")).forEach(System.out::println);
        //Q2:How to find duplicate elements in a given integers list in java using Stream functions?
        Set set=new HashSet();
        myList.stream().filter(a->!set.add(a)).forEach(System.out::println);
        //Q3:Given the list of integers, find the first element of the list using Stream functions?
        myList.stream().findFirst().ifPresent(System.out::println);
        //Q4:Given a list of integers, find the total number of elements present in the list using Stream functions?
        Long count= myList.stream().count();
        System.out.println(count);
        //Q5:Given a list of integers, find the maximum value element present in it using Stream functions?
        long max=myList.stream().max((a,b)->a.compare(a,b)).get();
        System.out.println(max);
        //Q6:Given a String, find the first non-repeated character in it using Stream functions?
        Set set1  = new LinkedHashSet();
        String input = "Java Hungry Blog Alive is Awesome";
       // input.chars().mapToObj(s->Character.toLowerCase(Character.valueOf((char) s))).filter(a->!set.add(a)).map()
        //Q7 Given a String, find the first repeated character in it using Stream functions?
        Set set2  = new LinkedHashSet();
        char c=input.chars().mapToObj(s->Character.toLowerCase(Character.valueOf((char)s))).filter(a->!set2.add(a)).findFirst().get();
        System.out.println("Q7:first repeated char is : "+c);
    }

}

