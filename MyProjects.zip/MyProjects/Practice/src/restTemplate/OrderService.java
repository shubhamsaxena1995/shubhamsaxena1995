package restTemplate;
public class OrderService {
/*@Service
public class OrderService {
    @Autowired
    private RuleUtil ruleUtil;

    public OrderResponse placeOrder(Order order){

        return ruleUtil.processOrder(order);
    }

    public OrderResponse getOrderDetail(String orderId){

        return ruleUtil.getOrderDetails(orderId);
    }*/
}
