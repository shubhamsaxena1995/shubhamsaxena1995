package restTemplate;

import org.omg.CORBA.Environment;

import javax.annotation.PostConstruct;
import java.awt.*;
import java.io.IOException;
public class RuleUtil {
/*@Component
@PropertySource(Value="classpath.application.properties")
public class RuleUtil {
    @Autowired
    private RestTemplate template;
    @AutoWired
    private Environment env;
    HttpHeader header=null;
    ObjectMapper mapper=null;
    @PostConstruct
    public void init(){
        header=new HttpHeader();
        header.setContentType(MediaType.APPLICATION_JSON);
        mapper=new ObjectMapper();
    }
    public OrderResponse processOrder(Order order){
        OrderResponse response=null;
      String jsonRequest;
      String result="";
        String requestUrl=null;
      try{
          requestUrl= env.getProperty("order.url");
          jsonRequest =mapper.writeValueAsString(order);
          HttpEntity <String> entity=new HttpEntity<String>(jsonRequest,header);
          result=mapper.postForObject(requestUrl,entity,String.class);
          response= mapper.readValue(result,OrderResponse.class);
      }
      catch (IOException e){
           e.printStackTrace();
      }
      return response;
    }
    public OrderResponse getOrderDetails(String orderId){
        OrderResponse response=null;
      //String jsonRequest;
      String result="";
        String requestUrl=null;
      try{
          requestUrl= env.getProperty("order.url")+orderId;
          //we don't need below code because we are doing GET call
         // requestUrl= env.getProperty("order.url");
         // jsonRequest =mapper.writeValueAsString(order);
         //  HttpEntity <String> entity=new HttpEntity<String>(jsonRequest,header);
         // result=mapper.postForObject(requestUrl,entity,String.class);
          result=mapper.getForObject(requestUrl,String.class);
          response= mapper.readValue(result,OrderResponse.class);
      }
      catch (IOException e){
           e.printStackTrace();
      }
      return response;
    }*/

}
