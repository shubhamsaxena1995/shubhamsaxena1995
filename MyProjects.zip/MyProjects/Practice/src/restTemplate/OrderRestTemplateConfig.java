package restTemplate;
public class OrderRestTemplateConfig {
/*@Configuration
public class OrderRestTemplateConfig {
 @Bean
 public RestTemplate getTemplate(){
   RestTemplate template=new RestTemplate();

   template.getMessageConverters().add(new StringHttpMessageConverter());
   template.getMessageConverters().add(new MappingJackson2HttpMessageConverter())
   return template;
 }*/
}
