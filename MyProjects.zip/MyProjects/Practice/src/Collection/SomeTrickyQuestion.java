package Collection;



import java.util.*;

public class SomeTrickyQuestion {
    public static void main(String[] args) {

        Set hashSet=new HashSet();
        Employee employee1=new Employee(10,"shubham");
        Employee employee2=new Employee(10,"ajay");
        hashSet.add(employee1);
        hashSet.add(employee2);
        System.out.println(hashSet);

        HashMap hashMap=new HashMap();
        hashMap.put(null,"second");
        hashMap.put(1,"first");
        hashMap.put(null,"aaaaa");
        hashMap.put(null,"bbbbb");
        System.out.println(hashMap);

        TreeSet treeSet=new TreeSet();
        treeSet.add(null);

        TreeMap treeMap=new TreeMap();
        treeMap.put(null,"first");
        System.out.println(treeMap);





    }
}
