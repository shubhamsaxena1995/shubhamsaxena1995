package EnhachedMultiThreading.cyclicBarrier;

import java.util.concurrent.CyclicBarrier;

public class CyclicBarrierExample {
    public static void main(String[] args) {
        CyclicBarrier barrier=new CyclicBarrier(4);
        PassengerThread passengerThread1=new PassengerThread(barrier,1000,"1111");
        PassengerThread passengerThread2=new PassengerThread(barrier,2000,"2222");
        PassengerThread passengerThread3=new PassengerThread(barrier,3000,"3333");
        PassengerThread passengerThread4=new PassengerThread(barrier,4000,"4444");

        PassengerThread passengerThread5=new PassengerThread(barrier,5000,"55555");
        PassengerThread passengerThread6=new PassengerThread(barrier,6000,"6666");
        PassengerThread passengerThread7=new PassengerThread(barrier,7000,"77777");
        PassengerThread passengerThread8=new PassengerThread(barrier,8000,"8888");

        passengerThread1.start();
        passengerThread2.start();
        passengerThread3.start();
        passengerThread4.start();

        passengerThread5.start();
        passengerThread6.start();
        passengerThread7.start();
        passengerThread8.start();

    }
}
