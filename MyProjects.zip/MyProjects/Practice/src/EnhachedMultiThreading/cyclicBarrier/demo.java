package EnhachedMultiThreading.cyclicBarrier;

import java.util.concurrent.CyclicBarrier;

public class demo {
    public static void main(String[] args) {
        CyclicBarrier cyclicBarrier=new CyclicBarrier(4);
        PracticePassangerThread practicePassangerThread1=new PracticePassangerThread(cyclicBarrier,1000,"AAA");
        PracticePassangerThread practicePassangerThread2=new PracticePassangerThread(cyclicBarrier,2000,"BBB");
        PracticePassangerThread practicePassangerThread3=new PracticePassangerThread(cyclicBarrier,3000,"CCC");
        PracticePassangerThread practicePassangerThread4=new PracticePassangerThread(cyclicBarrier,4000,"DDD");

        PracticePassangerThread practicePassangerThread5=new PracticePassangerThread(cyclicBarrier,5000,"EEE");
        PracticePassangerThread practicePassangerThread6=new PracticePassangerThread(cyclicBarrier,6000,"FFF");
        PracticePassangerThread practicePassangerThread7=new PracticePassangerThread(cyclicBarrier,7000,"GGG");
        PracticePassangerThread practicePassangerThread8=new PracticePassangerThread(cyclicBarrier,8000,"HHH");

        practicePassangerThread1.start();
        practicePassangerThread2.start();
        practicePassangerThread3.start();
        practicePassangerThread4.start();

        practicePassangerThread5.start();
        practicePassangerThread6.start();
        practicePassangerThread7.start();
        practicePassangerThread8.start();


    }
}
