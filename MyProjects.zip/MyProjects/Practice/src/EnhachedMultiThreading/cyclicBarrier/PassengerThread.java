package EnhachedMultiThreading.cyclicBarrier;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class PassengerThread extends Thread{
   private CyclicBarrier cyclicBarrier;
   private  int duration;
   public PassengerThread(CyclicBarrier cyclicBarrier,int duration,String passengerName){
       super(passengerName);
       this.cyclicBarrier=cyclicBarrier;
       this.duration=duration;
   }
   public void run(){
       try {
           Thread.sleep(duration);
           System.out.println(Thread.currentThread().getName()+" is arrived");
           int await=cyclicBarrier.await();
           if(await==0){
               System.out.println("Four passenger have arrived so can is going to start");
           }
       } catch (InterruptedException |BrokenBarrierException e) {
           e.printStackTrace();
       }

   }
 }