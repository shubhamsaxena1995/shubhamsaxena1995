package EnhachedMultiThreading.cyclicBarrier;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class PracticePassangerThread extends Thread{
    private long duration;
    private CyclicBarrier cyclicBarrier;
    PracticePassangerThread(CyclicBarrier cyclicBarrier,long duration,String passangerName){
        super(passangerName);
        this.duration=duration;
        this.cyclicBarrier=cyclicBarrier;
    }
    public void run(){
        try{
            Thread.sleep(duration);
            System.out.println(Thread.currentThread().getName()+" has arrived");
            int count=cyclicBarrier.await();
            if(count==0){
                System.out.println("all 4 passenger has arrived cab is ready for pick again");
            }
        }
       catch (InterruptedException | BrokenBarrierException ex){
            ex.printStackTrace();

       }
    }
}
