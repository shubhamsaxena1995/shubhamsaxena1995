package EnhachedMultiThreading.countDownLatch;

import java.util.concurrent.CountDownLatch;

public class DevTeam extends Thread{
    private CountDownLatch countDownLatch;
    public DevTeam(CountDownLatch countDownLatch,String devTeamName){
      super(devTeamName);
       this.countDownLatch=countDownLatch;
    }

    public void run(){
        System.out.println("Task assigned to dev team  :   "+Thread.currentThread().getName());

        try {
            Thread.sleep(1000);
        }
        catch (InterruptedException ex){
            ex.printStackTrace();
        }
        System.out.println("Task finished by dev team  :"+Thread.currentThread().getName());
        countDownLatch.countDown();
    }
}
