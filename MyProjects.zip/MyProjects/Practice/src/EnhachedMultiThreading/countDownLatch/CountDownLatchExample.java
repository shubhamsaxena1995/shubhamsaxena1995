package EnhachedMultiThreading.countDownLatch;

import java.util.concurrent.CountDownLatch;

public class CountDownLatchExample {
    public static void main(String[] args) throws InterruptedException {
        CountDownLatch countDownLatch=new CountDownLatch(2);
        DevTeam devTeamA=new DevTeam(countDownLatch,"DEV TEAM A");
        DevTeam devTeamB=new DevTeam(countDownLatch,"DEV TEAM B");

        devTeamA.start();
        devTeamB.start();

        countDownLatch.await();
        QaTeam qaTeam=new QaTeam("QA Team A");
        qaTeam.start();
    }
}
