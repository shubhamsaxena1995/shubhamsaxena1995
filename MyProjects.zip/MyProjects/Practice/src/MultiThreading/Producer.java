package MultiThreading;



public class Producer implements Runnable {
    MyQueue queue;

    Producer( MyQueue queue){
         this.queue=queue;
     }
    public  void run(){
      for(int i=0;i<=10;i++){
           queue.put(i);
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}

