package MultiThreading;

public class MyQueue {
    int num;
    boolean valueSet=false;
  public synchronized void  put(int num){

      while (valueSet){
          try {
              wait();
          } catch (InterruptedException e) {
              e.printStackTrace();
          }
      }
      this.num=num;
      System.out.println("put"+ this.num);
      valueSet=true;
      notify();
  }
  public synchronized void get(){
      while (!valueSet){
          try {
              wait();
          } catch (InterruptedException e) {
              e.printStackTrace();
          }
      }
      System.out.println("get"+ this.num);
      valueSet=false;
      notify();

  }

}
