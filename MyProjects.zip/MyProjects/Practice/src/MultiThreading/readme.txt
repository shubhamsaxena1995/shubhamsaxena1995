Youtube telusko
13.8 Multithreading InterThread Communication | Producer Consumer