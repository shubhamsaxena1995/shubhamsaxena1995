package MultiThreading;

import java.util.Queue;

public class ProducerConsumerDemo {
    public static void main(String[] args) throws InterruptedException {
        MyQueue queue =new MyQueue();
        Producer producer=new Producer(queue);
        Thread producerThread=new Thread(producer);
        producerThread.start();
        Consumer consumer = new Consumer(queue);
        Thread consumerThread=new Thread(consumer);
        consumerThread.start();

    }
}
